-- World Life Expectancy project (Data Cleaning)
-- Trying to identify duplicates and then remove them

SELECT *
 FROM world_life_expectancy;
 
 
 
 
 SELECT Country , Year, concat(Country, Year), count(concat(Country, Year))
 FROM world_life_expectancy
 GROUP BY  Country , Year
 HAVING  count(concat(Country, Year)) > 1 ;
 
 
 SELECT *
 FROM (
			SELECT ROW_ID,
			CONCAT(Country, Year),
			ROW_NUMBER() OVER( PARTITION BY CONCAT(Country, Year) ORDER BY Country, Year) as ROW_NUM
			FROM world_life_expectancy
            ) AS Row_table
WHERE ROW_NUM >1
;

DELETE FROM world_life_expectancy
WHERE
			ROW_ID IN (
            SELECT ROW_ID
 FROM (
			SELECT ROW_ID,
			CONCAT(Country, Year),
			ROW_NUMBER() OVER( PARTITION BY CONCAT(Country, Year) ORDER BY Country, Year) as ROW_NUM
			FROM world_life_expectancy
            ) AS Row_table
WHERE ROW_NUM >1);
            